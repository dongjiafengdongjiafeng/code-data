<?php
if($_GET['s'] == "init") {
	$cb = array("msg" => "ok");
} elseif ($_GET['s'] == "ping") {
	$cb = array("msg" => "pong");
} else {
	$cb = array("msg" => "begin");
}

$json_out = json_encode($cb);
$msg_out = "jsonpCallback($json_out)";
echo $msg_out;
?>