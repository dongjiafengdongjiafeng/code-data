<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_thumb = "127.0.0.1";
$database_thumb = "thumb";
$username_thumb = "thumb";
$password_thumb = "xxxx";
$thumb = mysql_pconnect($hostname_thumb, $username_thumb, $password_thumb) or trigger_error(mysql_error(),E_USER_ERROR); 

?>