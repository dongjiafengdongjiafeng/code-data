<?php
$_rd = $_GET['rd'];
$client = $_GET['client'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Javascript Test (XSS)</title>
<script type="text/javascript">
//xhr for uploading result
var xmlhttp=false;
if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
	try {
		xmlhttp = new XMLHttpRequest();
	} catch (e) {
		xmlhttp=false;
	}
}
if (!xmlhttp && window.createRequest) {
	try {
		xmlhttp = window.createRequest();
	} catch (e) {
		xmlhttp=false;
	}
}
var t1;
var t2;
var t3;
var t4;

function jsonpCallback(result){
	var tmp_t = new Date().getTime();
	
	if(result.msg == "begin") {	//send new request
		var script1 = document.createElement("script");
		script1.type = "text/javascript";
		script1.src = "xss_backend.php?s=init";		
		
		t1 = new Date().getTime();
		document.getElementsByTagName("HEAD")[0].appendChild(script1);
	} else {
		if(result.msg == "ok") {
			t2 = tmp_t;
			var script2 = document.createElement("script");
			script2.type = "text/javascript";
			script2.src = "xss_backend.php?s=ping";	
			t3 = new Date().getTime();
			document.getElementsByTagName("HEAD")[0].appendChild(script2);
		} else if(result.msg == "pong") {
			t4 = tmp_t;
			//finish
			store_url = "store.php?type=xss&rd=<?php echo $_rd; ?>&t1=" + t1 + "&t2=" + t2 + "&t3=" + t3 + "&t4=" + t4 +"&client=<?php echo $client; ?>";
			xmlhttp.open("GET", store_url, true);
			xmlhttp.send(null);
			
			var s1 = document.getElementById("t1");
			var s2 = document.getElementById("t2");
			var s3 = document.getElementById("t3");
			var s4 = document.getElementById("t4");
			var s5 = document.getElementById("s");
			s1.innerHTML = t1;
			s2.innerHTML = t2;
			s3.innerHTML = t3;
			s4.innerHTML = t4;
			s5.innerHTML = store_url;
			xmlhttp=false;
		}
	}	
}
</script>
<script type="text/javascript" src="xss_backend.php"></script>
</head>

<body>
<div id="forjs"></div>
<p id="t1"></p>
<p id="t2"></p>
<p id="t3"></p>
<p id="t4"></p>
<p id="s"></p>
</body>
</html>