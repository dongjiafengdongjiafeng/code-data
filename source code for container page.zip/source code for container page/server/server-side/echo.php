<?php
if(($_GET['s'] == "init") || ($_POST['s'] == "init")) {
	echo "ok";
} elseif (($_GET['s'] == "ping") || ($_POST['s'] == "ping")) {
	echo "pong";
} else {
	print_r($_POST);
}
?>