FILE LIST
====================
store.php		backend script for storing measurement results
db.php		database settings (required by store.php)
func.php		basic functions (required by store.php)

echo.php		backend script for XHR GET/POST, Flash GET/POST, and Java Applet GET/POST test
xss_backend.php	backend script for DOM test
pgServer.java/pgServer.class/ServerThread.class	backend script for Java Applet TCP socket and Flash TCP socket test
server.php	backend script for WebSocket test
ws_api.php	required by server.php

xhr_get.php	frontend script for XHR GET test
xhr_post.php	frontend script for XHR POST test
xss.php		frontend script for DOM test
wsclient.php	frontend script for WebSocket test
fl_get.php		frontend script for Flash GET test
fl_post.php	frontend script for Flash POST test
fl_socket.php	frontend script for Flash TCP socket test
ja_get.php	frontend script for Java Applet GET test
ja_post.php	frontend script for Java Applet POST test
ja_tcp.php	frontend script for Java Applet TCP socket test

fl_get.swf		Flash object for Flash GET test
fl_post.swf	Flash object for Flash POST test
fl_socket.swf	Flash object for Flash TCP socket test
ja_get.class	Java applet for GET test
ja_post.class	Java applet for POST test
ja_tcp.class	Java applet for TCP socket test
