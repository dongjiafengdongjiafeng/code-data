<?php
$_rd = $_GET['rd'];
$client = $_GET['client'];
$ts = time();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Java Applet Test (TCP Socket)</title>
</head>

<body>
<applet code="ja_get.class" width="400" height="400">
  <param name="rd" value="<?php echo $_rd; ?>" />
  <param name="cl" value="<?php echo $client; ?>" />
</applet>
</body>
</html>