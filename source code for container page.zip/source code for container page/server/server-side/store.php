<?php
require_once('db.php');
require_once('func.php');

if(!isset($_GET['type']) || !isset($_GET['rd']) || !isset($_GET['t1']) || !isset($_GET['t2']) || !isset($_GET['t3']) || !isset($_GET['t4']) || !isset($_GET['client'])) {
	exit('error');
}

$type = $_GET['type'];
$rd = $_GET['rd'];
$t1 = $_GET['t1'];
$t2 = $_GET['t2'];
$t3 = $_GET['t3'];
$t4 = $_GET['t4'];
$client_info = $_GET['client'];

mysql_select_db($database_thumb, $thumb);
$ins = sprintf("INSERT INTO exp (rtype, rd, t1, t2, t3, t4, client_info) VALUES (%s, %d, %d, %d, %d, %d, %s)", 
								GetSQLValueString($type, "text"), 
								GetSQLValueString($rd, "int"),
								GetSQLValueString($t1, "int"),
								GetSQLValueString($t2, "int"),
								GetSQLValueString($t3, "int"),
								GetSQLValueString($t4, "int"),
								GetSQLValueString($client_info, "text"));
mysql_query($ins) or die(mysql_error());
echo "e";
?>