//import java.awt.*;
import java.net.*;
import java.io.*;
//import java.lang.*;
//import java.util.*;

public class pgServer {
	public static void main(String args[]) {
		try {
			ServerSocket serverSocket = new ServerSocket(8205);
			
			while (true) {
				Socket incoming = serverSocket.accept();
				
				ServerThread pt = new ServerThread(incoming);
				pt.start();
			}
		} catch (Exception exc) {
			System.out.println("Error! - " + exc.toString());
		}
	}
}

class ServerThread extends Thread {
	Socket incoming;
	ServerThread(Socket s) {
		this.incoming = s;
		System.out.println("Connection established.");
	}
	
	public void run() {
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(incoming.getInputStream(), "UTF-8"));
			PrintWriter out = new PrintWriter(incoming.getOutputStream(), true);
			
			while(true) {
				String line = in.readLine();
				System.out.println(line);
				String inline = line.substring(0,4);
				System.out.println(inline);
				
				if(inline.equals("init")) {
					out.println("ok");
					out.flush();
				} else if(inline.equals("ping")) {
					out.println("pong");
					out.flush();
					break;
				}
			}
			out.println("closing");
			System.out.println("Connection closed.");
			incoming.close();
		} catch (NullPointerException exc) {
			System.out.println("Client has closed the connection!");
		} catch (Exception exc) {
			System.out.println("Error! - " + exc.toString());
		}
		
		/*
		try {
			incoming.close();
		} catch (Exception exc) {
			System.out.println("Error! - " + exc.toString());
		}*/
	}
}
