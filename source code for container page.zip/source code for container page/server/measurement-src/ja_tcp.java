import java.applet.*;
import java.awt.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class ja_tcp extends Applet {
	Socket socket;
	BufferedReader in;
	PrintWriter out;
	
	//DataInputStream inStream;
	//PrintStream outStream;
	String rd;
	String cl;
	String store_link;
	
	String outWords1 = "init";
	String outWords2 = "ping";
	long t1;
	long t2;
	long t3;
	long t4;
	long t1n;
	long t2n;
	long t3n;
	long t4n;
	
	public void init() {		
		try {
			rd = getParameter("rd");
			cl = getParameter("cl");
			
			socket = new Socket("158.132.255.32", 8205);
			
			in = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"));
			out = new PrintWriter(socket.getOutputStream(), true);
			
			try {
				out.println(outWords1);
				//t1n = System.nanoTime();
				t1 = new Date().getTime();
				out.flush();
				
				while(true) {
					String inStr = in.readLine();
					//long tmp_t = System.nanoTime();
					long tmp_t = new Date().getTime();
					
					if(inStr.equals("ok")) {
						/*
						try{
							TimeUnit.SECONDS.sleep(2);
						} catch (InterruptedException e){
							e.printStackTrace();
						}*/
						
						//t2n = tmp_t;
						t2 = tmp_t;
						out.println(outWords2);
						
						t3 = new Date().getTime();
						//t3n = System.nanoTime();
						out.flush();
					} else if(inStr.equals("pong")) {
						try{
							TimeUnit.SECONDS.sleep(1);
						} catch (InterruptedException e){
							e.printStackTrace();
						}
						//upload results
						//t4n = tmp_t;
						t4 = tmp_t;
						
						store_link = "http://158.132.255.32:25001/thumb/delay_test/store.php?type=ja_tcp&rd="+rd+"&t1="+t1+"&t2="+t2+"&t3="+t3+"&t4="+t4+"&client="+cl;
						URL url = new URL(store_link);
						URLConnection urlconn = url.openConnection();
						urlconn.setDoInput(true);   
						urlconn.setDoOutput(true);   
						urlconn.setUseCaches(false);   
						urlconn.setRequestProperty("Content-Type", "application/x-java-serialized-object"); 
						DataInputStream urlin = new DataInputStream(urlconn.getInputStream()); 
						//response = urlin.readUTF(); 
						urlin.close();
						//HttpURLConnection http_conn = (HttpURLConnection) urlConn;
						//http_conn.setRequestMethod("GET");
						//urlconn.connect();
						
						break;
					}
				}
				socket.close();
				//System.out.println(store_link);
			} catch(Exception exc) {
				System.out.println("Error while sending out packets");
			}
			
		} catch(Exception exc) {
			System.out.println("Error while initialize the network");
		}
	}
	
	public void paint(Graphics g) {
		g.drawString(store_link, 20, 20);
		//g.drawString(t1 +"   " + t2, 20, 20);
	}
	
	/*
	public void readpkt() {
		try {
			String inStr = new String();
			inStr = in.readLine();
			System.out.println(inStr);
		} catch(Exception exc) {
			System.out.println("Error while receiving packets");
		}
	}*/
}
