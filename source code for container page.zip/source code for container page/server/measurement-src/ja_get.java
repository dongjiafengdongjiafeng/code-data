import java.applet.*;
import java.awt.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

//<applet code=ja_get width=300 height=200></applet>

public class ja_get extends Applet {
	HttpURLConnection httpconn1;
	
	String rd;
	String cl;
	String link1 = "http://158.132.255.32:25001/thumb/delay_test/echo.php?s=init";
	String link2 = "http://158.132.255.32:25001/thumb/delay_test/echo.php?s=ping";
	String store_link;
	
	long t1;
	long t2;
	long t3;
	long t4;
	long t1n;
	long t2n;
	long t3n;
	long t4n;
	//long d1;
	//long d2;
	
	String lines1, lines2;
	BufferedReader r1;
	BufferedReader r2;
	
	public void init() {		
		try {			
			rd = getParameter("rd");
			cl = getParameter("cl");
			
			URL url1 = new URL(link1);
			
			httpconn1 = (HttpURLConnection) url1.openConnection();
			
			httpconn1.setDoInput(true);   
			httpconn1.setDoOutput(true);   
			httpconn1.setUseCaches(false);   
			httpconn1.setRequestProperty("Content-Type", "application/x-java-serialized-object");
			httpconn1.setRequestMethod("GET");
			
			httpconn1.connect();
			
			t1 = new Date().getTime();
			//t1n = System.nanoTime();
			
			InputStream inStrm1 = httpconn1.getInputStream();
			
			r1 = new BufferedReader(new InputStreamReader(inStrm1, "utf-8"));
			t2 = new Date().getTime();
			//t2n = System.nanoTime();
			
			//d1 = (t2n-t1n)/(1000*1000);
			//System.out.println(d1);
			
			lines1 = r1.readLine();
			r1.close();
			
			/*
			long d1 = t2-t1;
			String sd1 = Long.toString(d1);
			System.out.println(sd1);*/
			
			if(lines1.equals("ok")) {
				//System.out.println(lines);
				/*
				try{
					TimeUnit.SECONDS.sleep(2);
				} catch (InterruptedException e){
					e.printStackTrace();
				}*/
				
				URL url2 = new URL(link2);
				
				httpconn1 = (HttpURLConnection) url2.openConnection();
				httpconn1.connect();
				t3 = new Date().getTime();
				//t3n = System.nanoTime();
				
				InputStream inStrm2 = httpconn1.getInputStream();
				t4 = new Date().getTime();
				//t4n = System.nanoTime();
				r2 = new BufferedReader(new InputStreamReader(inStrm2, "utf-8"));
				
				//d2 = (t4n-t3n)/(1000*1000);
				//System.out.println(d2);
				
				lines2 = r2.readLine();
				r2.close();
				//System.out.println(lines2);
				
				if(lines2.equals("pong")) {
					try{
						TimeUnit.SECONDS.sleep(1);
					} catch (InterruptedException e){
						e.printStackTrace();
					}
										
					store_link = "http://158.132.255.32:25001/thumb/delay_test/store.php?type=ja_get&rd="+rd+"&t1="+t1+"&t2="+t2+"&t3="+t3+"&t4="+t4+"&client="+cl;
					URL store_url = new URL(store_link);
					httpconn1 = (HttpURLConnection) store_url.openConnection();
					//httpconn1.connect();
					httpconn1.getInputStream();
					httpconn1.disconnect();
				}
			}
						
		} catch(Exception exc) {
			System.out.println("Error while initialize the network");
		}
	}
	
	
	public void paint(Graphics g) {
		g.drawString(store_link, 20, 20);
		//g.drawString(t1 +"   " + t2, 20, 20);
	}
}
