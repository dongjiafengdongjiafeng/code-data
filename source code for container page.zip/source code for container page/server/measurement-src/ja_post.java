import java.applet.*;
import java.awt.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class ja_post extends Applet {
	HttpURLConnection httpconn1, httpconn2;
	
	String rd;
	String cl;
	String link1 = "http://158.132.255.32:25001/thumb/delay_test/echo.php";
	String store_link;
	
	long t1;
	long t2;
	long t3;
	long t4;
	long t1n;
	long t2n;
	long t3n;
	long t4n;
	
	String lines1, lines2;
	BufferedReader r1;
	BufferedReader r2;
	
	public void init() {		
		try {
			rd = getParameter("rd");
			cl = getParameter("cl");
			
			URL url1 = new URL(link1);
			
			httpconn1 = (HttpURLConnection) url1.openConnection();
			
			httpconn1.setDoInput(true);   
			httpconn1.setDoOutput(true);   
			httpconn1.setUseCaches(false);   
			httpconn1.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			httpconn1.setRequestMethod("POST");
			//httpconn1.connect();
			
			DataOutputStream out1 = new DataOutputStream(httpconn1.getOutputStream());
			
			out1.writeBytes("s=init");
			out1.flush();
			out1.close();
			
			t1 = new Date().getTime();
			//t1n = System.nanoTime();
			InputStream inStrm1 = httpconn1.getInputStream();
			t2 = new Date().getTime();
			//t2n = System.nanoTime();
			r1 = new BufferedReader(new InputStreamReader(inStrm1, "utf-8"));
			
			lines1 = r1.readLine();
			r1.close();
			
			if(lines1.equals("ok")) {
				try{
					TimeUnit.SECONDS.sleep(2);
				} catch (InterruptedException e){
					e.printStackTrace();
				}
				
				URL url2 = new URL(link1);
				
				httpconn2 = (HttpURLConnection) url2.openConnection();
				
				httpconn2.setDoInput(true);   
				httpconn2.setDoOutput(true);   
				httpconn2.setUseCaches(false);   
				httpconn2.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
				httpconn2.setRequestMethod("POST");
				httpconn2.connect();
				
				DataOutputStream out2 = new DataOutputStream(httpconn2.getOutputStream());
				out2.writeBytes("s=ping");
				out2.flush();
				out2.close();
				
				t3 = new Date().getTime();
				//t3n = System.nanoTime();
				InputStream inStrm2 = httpconn2.getInputStream();
				
				t4 = new Date().getTime();
				//t4n = System.nanoTime();
				r2 = new BufferedReader(new InputStreamReader(inStrm2, "utf-8"));
				
				lines2 = r2.readLine();
				r2.close();				
				
				if(lines2.equals("pong")) {
					try{
						TimeUnit.SECONDS.sleep(1);
					} catch (InterruptedException e){
						e.printStackTrace();
					}
										
					store_link = "http://158.132.255.32:25001/thumb/delay_test/store.php?type=ja_post&rd="+rd+"&t1="+t1+"&t2="+t2+"&t3="+t3+"&t4="+t4+"&client="+cl;
					URL store_url = new URL(store_link);
					httpconn2 = (HttpURLConnection) store_url.openConnection();
					httpconn2.setRequestMethod("GET");
					//httpconn1.connect();
					httpconn2.getInputStream();
					
					httpconn1.disconnect();
					httpconn2.disconnect();
				}
			}
						
		} catch(Exception exc) {
			System.out.println("Error while initialize the network");
		}
	}
	
	
	public void paint(Graphics g) {
		g.drawString(store_link, 20, 20);
		//g.drawString(t1 +"   " + t2, 20, 20);
	}
}
